﻿namespace csweb
{
    partial class appForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.urlTextBox = new System.Windows.Forms.TextBox();
            this.sendUrlButton = new System.Windows.Forms.Button();
            this.httpMethodsComboBox = new System.Windows.Forms.ComboBox();
            this.postDataCheckbox = new System.Windows.Forms.CheckBox();
            this.dataPayloadTextBox = new System.Windows.Forms.TextBox();
            this.userAgentDisplayLabel = new System.Windows.Forms.Label();
            this.userAgentTextBox = new System.Windows.Forms.TextBox();
            this.httpProtocolComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.resetValuesButton = new System.Windows.Forms.Button();
            this.contentTypeComboBox = new System.Windows.Forms.ComboBox();
            this.cookieHeaderCheckBox = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.responseTextBox = new System.Windows.Forms.RichTextBox();
            this.cookieHeaderTextBox = new System.Windows.Forms.TextBox();
            this.searchResponseTextBox = new System.Windows.Forms.TextBox();
            this.searchResponseButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.matchesCountLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // urlTextBox
            // 
            this.urlTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urlTextBox.Location = new System.Drawing.Point(283, 18);
            this.urlTextBox.Name = "urlTextBox";
            this.urlTextBox.Size = new System.Drawing.Size(447, 29);
            this.urlTextBox.TabIndex = 1;
            // 
            // sendUrlButton
            // 
            this.sendUrlButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendUrlButton.Location = new System.Drawing.Point(179, 407);
            this.sendUrlButton.Name = "sendUrlButton";
            this.sendUrlButton.Size = new System.Drawing.Size(94, 36);
            this.sendUrlButton.TabIndex = 2;
            this.sendUrlButton.Text = "Send";
            this.sendUrlButton.UseVisualStyleBackColor = true;
            this.sendUrlButton.Click += new System.EventHandler(this.sendUrlButton_Click);
            // 
            // httpMethodsComboBox
            // 
            this.httpMethodsComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.httpMethodsComboBox.FormattingEnabled = true;
            this.httpMethodsComboBox.Items.AddRange(new object[] {
            "GET",
            "HEAD",
            "POST",
            "PUT",
            "DELETE",
            "TRACE",
            "OPTIONS",
            "CONNECT",
            "PATCH"});
            this.httpMethodsComboBox.Location = new System.Drawing.Point(30, 18);
            this.httpMethodsComboBox.Name = "httpMethodsComboBox";
            this.httpMethodsComboBox.Size = new System.Drawing.Size(121, 32);
            this.httpMethodsComboBox.TabIndex = 5;
            this.httpMethodsComboBox.Text = "GET";
            // 
            // postDataCheckbox
            // 
            this.postDataCheckbox.AutoSize = true;
            this.postDataCheckbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postDataCheckbox.Location = new System.Drawing.Point(85, 113);
            this.postDataCheckbox.Name = "postDataCheckbox";
            this.postDataCheckbox.Size = new System.Drawing.Size(143, 28);
            this.postDataCheckbox.TabIndex = 6;
            this.postDataCheckbox.Text = "Content-Type";
            this.postDataCheckbox.UseVisualStyleBackColor = true;
            this.postDataCheckbox.CheckedChanged += new System.EventHandler(this.postDataCheckbox_CheckedChanged);
            // 
            // dataPayloadTextBox
            // 
            this.dataPayloadTextBox.Enabled = false;
            this.dataPayloadTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataPayloadTextBox.Location = new System.Drawing.Point(234, 155);
            this.dataPayloadTextBox.Multiline = true;
            this.dataPayloadTextBox.Name = "dataPayloadTextBox";
            this.dataPayloadTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataPayloadTextBox.Size = new System.Drawing.Size(496, 62);
            this.dataPayloadTextBox.TabIndex = 7;
            this.dataPayloadTextBox.EnabledChanged += new System.EventHandler(this.postDataCheckbox_CheckedChanged);
            // 
            // userAgentDisplayLabel
            // 
            this.userAgentDisplayLabel.AutoSize = true;
            this.userAgentDisplayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAgentDisplayLabel.Location = new System.Drawing.Point(46, 65);
            this.userAgentDisplayLabel.Name = "userAgentDisplayLabel";
            this.userAgentDisplayLabel.Size = new System.Drawing.Size(105, 24);
            this.userAgentDisplayLabel.TabIndex = 8;
            this.userAgentDisplayLabel.Text = "User-Agent";
            // 
            // userAgentTextBox
            // 
            this.userAgentTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAgentTextBox.Location = new System.Drawing.Point(157, 65);
            this.userAgentTextBox.Name = "userAgentTextBox";
            this.userAgentTextBox.Size = new System.Drawing.Size(573, 29);
            this.userAgentTextBox.TabIndex = 9;
            this.userAgentTextBox.Text = "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.10" +
    "90.0 Safari/536.6";
            // 
            // httpProtocolComboBox
            // 
            this.httpProtocolComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.httpProtocolComboBox.FormattingEnabled = true;
            this.httpProtocolComboBox.Items.AddRange(new object[] {
            "HTTP",
            "HTTPS",
            "FTP"});
            this.httpProtocolComboBox.Location = new System.Drawing.Point(157, 18);
            this.httpProtocolComboBox.Name = "httpProtocolComboBox";
            this.httpProtocolComboBox.Size = new System.Drawing.Size(89, 32);
            this.httpProtocolComboBox.TabIndex = 10;
            this.httpProtocolComboBox.Text = "HTTP";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(252, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "://";
            // 
            // resetValuesButton
            // 
            this.resetValuesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetValuesButton.Location = new System.Drawing.Point(283, 407);
            this.resetValuesButton.Name = "resetValuesButton";
            this.resetValuesButton.Size = new System.Drawing.Size(94, 36);
            this.resetValuesButton.TabIndex = 12;
            this.resetValuesButton.Text = "Reset";
            this.resetValuesButton.UseVisualStyleBackColor = true;
            this.resetValuesButton.Click += new System.EventHandler(this.resetValuesButton_Click);
            // 
            // contentTypeComboBox
            // 
            this.contentTypeComboBox.Enabled = false;
            this.contentTypeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contentTypeComboBox.FormattingEnabled = true;
            this.contentTypeComboBox.Items.AddRange(new object[] {
            "application/x-www-form-urlencoded"});
            this.contentTypeComboBox.Location = new System.Drawing.Point(234, 111);
            this.contentTypeComboBox.Name = "contentTypeComboBox";
            this.contentTypeComboBox.Size = new System.Drawing.Size(496, 32);
            this.contentTypeComboBox.TabIndex = 13;
            this.contentTypeComboBox.Text = "application/x-www-form-urlencoded";
            // 
            // cookieHeaderCheckBox
            // 
            this.cookieHeaderCheckBox.AutoSize = true;
            this.cookieHeaderCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cookieHeaderCheckBox.Location = new System.Drawing.Point(85, 347);
            this.cookieHeaderCheckBox.Name = "cookieHeaderCheckBox";
            this.cookieHeaderCheckBox.Size = new System.Drawing.Size(88, 28);
            this.cookieHeaderCheckBox.TabIndex = 16;
            this.cookieHeaderCheckBox.Text = "Cookie";
            this.cookieHeaderCheckBox.UseVisualStyleBackColor = true;
            this.cookieHeaderCheckBox.CheckedChanged += new System.EventHandler(this.cookieHeaderCheckBox_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(151, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 24);
            this.label2.TabIndex = 18;
            this.label2.Text = "Payload";
            // 
            // responseTextBox
            // 
            this.responseTextBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.responseTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.responseTextBox.Location = new System.Drawing.Point(762, 18);
            this.responseTextBox.Name = "responseTextBox";
            this.responseTextBox.ReadOnly = true;
            this.responseTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.responseTextBox.Size = new System.Drawing.Size(738, 520);
            this.responseTextBox.TabIndex = 19;
            this.responseTextBox.Text = "";
            // 
            // cookieHeaderTextBox
            // 
            this.cookieHeaderTextBox.Enabled = false;
            this.cookieHeaderTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cookieHeaderTextBox.Location = new System.Drawing.Point(179, 347);
            this.cookieHeaderTextBox.Name = "cookieHeaderTextBox";
            this.cookieHeaderTextBox.Size = new System.Drawing.Size(550, 29);
            this.cookieHeaderTextBox.TabIndex = 17;
            // 
            // searchResponseTextBox
            // 
            this.searchResponseTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchResponseTextBox.Location = new System.Drawing.Point(870, 555);
            this.searchResponseTextBox.Name = "searchResponseTextBox";
            this.searchResponseTextBox.Size = new System.Drawing.Size(461, 29);
            this.searchResponseTextBox.TabIndex = 21;
            // 
            // searchResponseButton
            // 
            this.searchResponseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchResponseButton.Location = new System.Drawing.Point(762, 554);
            this.searchResponseButton.Name = "searchResponseButton";
            this.searchResponseButton.Size = new System.Drawing.Size(90, 33);
            this.searchResponseButton.TabIndex = 22;
            this.searchResponseButton.Text = "Search";
            this.searchResponseButton.UseVisualStyleBackColor = true;
            this.searchResponseButton.Click += new System.EventHandler(this.searchResponseButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1350, 558);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 24);
            this.label3.TabIndex = 23;
            this.label3.Text = "Matches: ";
            // 
            // matchesCountLabel
            // 
            this.matchesCountLabel.AutoSize = true;
            this.matchesCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matchesCountLabel.Location = new System.Drawing.Point(1447, 558);
            this.matchesCountLabel.Name = "matchesCountLabel";
            this.matchesCountLabel.Size = new System.Drawing.Size(20, 24);
            this.matchesCountLabel.TabIndex = 24;
            this.matchesCountLabel.Text = "0";
            // 
            // appForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1516, 601);
            this.Controls.Add(this.matchesCountLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.searchResponseButton);
            this.Controls.Add(this.searchResponseTextBox);
            this.Controls.Add(this.responseTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cookieHeaderTextBox);
            this.Controls.Add(this.cookieHeaderCheckBox);
            this.Controls.Add(this.contentTypeComboBox);
            this.Controls.Add(this.resetValuesButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.httpProtocolComboBox);
            this.Controls.Add(this.userAgentTextBox);
            this.Controls.Add(this.userAgentDisplayLabel);
            this.Controls.Add(this.dataPayloadTextBox);
            this.Controls.Add(this.postDataCheckbox);
            this.Controls.Add(this.httpMethodsComboBox);
            this.Controls.Add(this.sendUrlButton);
            this.Controls.Add(this.urlTextBox);
            this.Name = "appForm";
            this.Text = "csweb";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox urlTextBox;
        private System.Windows.Forms.Button sendUrlButton;
        private System.Windows.Forms.ComboBox httpMethodsComboBox;
        private System.Windows.Forms.CheckBox postDataCheckbox;
        private System.Windows.Forms.TextBox dataPayloadTextBox;
        private System.Windows.Forms.Label userAgentDisplayLabel;
        private System.Windows.Forms.TextBox userAgentTextBox;
        private System.Windows.Forms.ComboBox httpProtocolComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button resetValuesButton;
        private System.Windows.Forms.ComboBox contentTypeComboBox;
        private System.Windows.Forms.CheckBox cookieHeaderCheckBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox responseTextBox;
        private System.Windows.Forms.TextBox cookieHeaderTextBox;
        private System.Windows.Forms.TextBox searchResponseTextBox;
        private System.Windows.Forms.Button searchResponseButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label matchesCountLabel;
    }
}

