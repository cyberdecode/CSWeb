﻿namespace csweb
{
    partial class appForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.urlTextBox = new System.Windows.Forms.TextBox();
            this.sendUrlButton = new System.Windows.Forms.Button();
            this.httpMethodsComboBox = new System.Windows.Forms.ComboBox();
            this.postDataCheckbox = new System.Windows.Forms.CheckBox();
            this.dataPayloadTextBox = new System.Windows.Forms.TextBox();
            this.userAgentDisplayLabel = new System.Windows.Forms.Label();
            this.userAgentTextBox = new System.Windows.Forms.TextBox();
            this.httpProtocolComboBox = new System.Windows.Forms.ComboBox();
            this.resetValuesButton = new System.Windows.Forms.Button();
            this.contentTypeComboBox = new System.Windows.Forms.ComboBox();
            this.hostHeaderCheckBox = new System.Windows.Forms.CheckBox();
            this.responseTextBox = new System.Windows.Forms.RichTextBox();
            this.hostHeaderTextBox = new System.Windows.Forms.TextBox();
            this.searchResponseTextBox = new System.Windows.Forms.TextBox();
            this.searchResponseButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.matchesCountLabel = new System.Windows.Forms.Label();
            this.fileUploadButton = new System.Windows.Forms.Button();
            this.fileUploadName = new System.Windows.Forms.Label();
            this.customHeaderChkBox1 = new System.Windows.Forms.CheckBox();
            this.customHeaderKeyTxtBox1 = new System.Windows.Forms.TextBox();
            this.customHeaderValueTxtBox1 = new System.Windows.Forms.TextBox();
            this.customHeaderChkBox2 = new System.Windows.Forms.CheckBox();
            this.customHeaderKeyTxtBox2 = new System.Windows.Forms.TextBox();
            this.customHeaderValueTxtBox2 = new System.Windows.Forms.TextBox();
            this.keyLabelDisplay = new System.Windows.Forms.Label();
            this.valueLabelDisplay = new System.Windows.Forms.Label();
            this.customHeaderChkBox3 = new System.Windows.Forms.CheckBox();
            this.customHeaderKeyTxtBox3 = new System.Windows.Forms.TextBox();
            this.customHeaderValueTxtBox3 = new System.Windows.Forms.TextBox();
            this.dataPayloadCheckBox = new System.Windows.Forms.CheckBox();
            this.fileUploadCheckBox = new System.Windows.Forms.CheckBox();
            this.cookieHeaderCheckBox = new System.Windows.Forms.CheckBox();
            this.cookieHeaderTextBox = new System.Windows.Forms.TextBox();
            this.refererHeaderCheckBox = new System.Windows.Forms.CheckBox();
            this.refererHeaderTextBox = new System.Windows.Forms.TextBox();
            this.redirectsCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // urlTextBox
            // 
            this.urlTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urlTextBox.Location = new System.Drawing.Point(207, 15);
            this.urlTextBox.Name = "urlTextBox";
            this.urlTextBox.Size = new System.Drawing.Size(261, 22);
            this.urlTextBox.TabIndex = 1;
            // 
            // sendUrlButton
            // 
            this.sendUrlButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.sendUrlButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendUrlButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.sendUrlButton.Location = new System.Drawing.Point(362, 416);
            this.sendUrlButton.Name = "sendUrlButton";
            this.sendUrlButton.Size = new System.Drawing.Size(90, 33);
            this.sendUrlButton.TabIndex = 2;
            this.sendUrlButton.Text = "Send";
            this.sendUrlButton.UseVisualStyleBackColor = false;
            this.sendUrlButton.Click += new System.EventHandler(this.sendUrlButton_Click);
            // 
            // httpMethodsComboBox
            // 
            this.httpMethodsComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.httpMethodsComboBox.FormattingEnabled = true;
            this.httpMethodsComboBox.Items.AddRange(new object[] {
            "GET",
            "HEAD",
            "POST",
            "PUT",
            "DELETE",
            "TRACE",
            "OPTIONS",
            "CONNECT",
            "PATCH"});
            this.httpMethodsComboBox.Location = new System.Drawing.Point(25, 14);
            this.httpMethodsComboBox.Name = "httpMethodsComboBox";
            this.httpMethodsComboBox.Size = new System.Drawing.Size(92, 24);
            this.httpMethodsComboBox.TabIndex = 5;
            this.httpMethodsComboBox.Text = "GET";
            // 
            // postDataCheckbox
            // 
            this.postDataCheckbox.AutoSize = true;
            this.postDataCheckbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postDataCheckbox.Location = new System.Drawing.Point(26, 281);
            this.postDataCheckbox.Name = "postDataCheckbox";
            this.postDataCheckbox.Size = new System.Drawing.Size(108, 20);
            this.postDataCheckbox.TabIndex = 6;
            this.postDataCheckbox.Text = "Content-Type";
            this.postDataCheckbox.UseVisualStyleBackColor = true;
            this.postDataCheckbox.CheckedChanged += new System.EventHandler(this.postDataCheckbox_CheckedChanged);
            // 
            // dataPayloadTextBox
            // 
            this.dataPayloadTextBox.Enabled = false;
            this.dataPayloadTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataPayloadTextBox.Location = new System.Drawing.Point(91, 312);
            this.dataPayloadTextBox.Multiline = true;
            this.dataPayloadTextBox.Name = "dataPayloadTextBox";
            this.dataPayloadTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataPayloadTextBox.Size = new System.Drawing.Size(470, 57);
            this.dataPayloadTextBox.TabIndex = 7;
            this.dataPayloadTextBox.EnabledChanged += new System.EventHandler(this.postDataCheckbox_CheckedChanged);
            // 
            // userAgentDisplayLabel
            // 
            this.userAgentDisplayLabel.AutoSize = true;
            this.userAgentDisplayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAgentDisplayLabel.Location = new System.Drawing.Point(21, 52);
            this.userAgentDisplayLabel.Name = "userAgentDisplayLabel";
            this.userAgentDisplayLabel.Size = new System.Drawing.Size(76, 16);
            this.userAgentDisplayLabel.TabIndex = 8;
            this.userAgentDisplayLabel.Text = "User-Agent";
            // 
            // userAgentTextBox
            // 
            this.userAgentTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAgentTextBox.Location = new System.Drawing.Point(103, 49);
            this.userAgentTextBox.Name = "userAgentTextBox";
            this.userAgentTextBox.Size = new System.Drawing.Size(456, 22);
            this.userAgentTextBox.TabIndex = 9;
            this.userAgentTextBox.Text = "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.10" +
    "90.0 Safari/536.6";
            // 
            // httpProtocolComboBox
            // 
            this.httpProtocolComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.httpProtocolComboBox.FormattingEnabled = true;
            this.httpProtocolComboBox.Items.AddRange(new object[] {
            "HTTP",
            "HTTPS",
            "FTP"});
            this.httpProtocolComboBox.Location = new System.Drawing.Point(123, 14);
            this.httpProtocolComboBox.Name = "httpProtocolComboBox";
            this.httpProtocolComboBox.Size = new System.Drawing.Size(78, 24);
            this.httpProtocolComboBox.TabIndex = 10;
            this.httpProtocolComboBox.Text = "HTTP";
            // 
            // resetValuesButton
            // 
            this.resetValuesButton.BackColor = System.Drawing.Color.IndianRed;
            this.resetValuesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetValuesButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.resetValuesButton.Location = new System.Drawing.Point(471, 416);
            this.resetValuesButton.Name = "resetValuesButton";
            this.resetValuesButton.Size = new System.Drawing.Size(90, 33);
            this.resetValuesButton.TabIndex = 12;
            this.resetValuesButton.Text = "Reset";
            this.resetValuesButton.UseVisualStyleBackColor = false;
            this.resetValuesButton.Click += new System.EventHandler(this.resetValuesButton_Click);
            // 
            // contentTypeComboBox
            // 
            this.contentTypeComboBox.Enabled = false;
            this.contentTypeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contentTypeComboBox.FormattingEnabled = true;
            this.contentTypeComboBox.Items.AddRange(new object[] {
            "application/x-www-form-urlencoded"});
            this.contentTypeComboBox.Location = new System.Drawing.Point(141, 279);
            this.contentTypeComboBox.Name = "contentTypeComboBox";
            this.contentTypeComboBox.Size = new System.Drawing.Size(420, 24);
            this.contentTypeComboBox.TabIndex = 13;
            this.contentTypeComboBox.Text = "application/x-www-form-urlencoded";
            // 
            // hostHeaderCheckBox
            // 
            this.hostHeaderCheckBox.AutoSize = true;
            this.hostHeaderCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hostHeaderCheckBox.Location = new System.Drawing.Point(24, 83);
            this.hostHeaderCheckBox.Name = "hostHeaderCheckBox";
            this.hostHeaderCheckBox.Size = new System.Drawing.Size(58, 20);
            this.hostHeaderCheckBox.TabIndex = 16;
            this.hostHeaderCheckBox.Text = "Host:";
            this.hostHeaderCheckBox.UseVisualStyleBackColor = true;
            this.hostHeaderCheckBox.CheckedChanged += new System.EventHandler(this.hostHeaderCheckBox_CheckedChanged);
            // 
            // responseTextBox
            // 
            this.responseTextBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.responseTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.responseTextBox.Location = new System.Drawing.Point(571, 15);
            this.responseTextBox.Name = "responseTextBox";
            this.responseTextBox.ReadOnly = true;
            this.responseTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.responseTextBox.Size = new System.Drawing.Size(595, 386);
            this.responseTextBox.TabIndex = 19;
            this.responseTextBox.Text = "";
            // 
            // hostHeaderTextBox
            // 
            this.hostHeaderTextBox.Enabled = false;
            this.hostHeaderTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hostHeaderTextBox.Location = new System.Drawing.Point(96, 81);
            this.hostHeaderTextBox.Name = "hostHeaderTextBox";
            this.hostHeaderTextBox.Size = new System.Drawing.Size(463, 22);
            this.hostHeaderTextBox.TabIndex = 17;
            // 
            // searchResponseTextBox
            // 
            this.searchResponseTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchResponseTextBox.Location = new System.Drawing.Point(667, 421);
            this.searchResponseTextBox.Name = "searchResponseTextBox";
            this.searchResponseTextBox.Size = new System.Drawing.Size(251, 22);
            this.searchResponseTextBox.TabIndex = 21;
            // 
            // searchResponseButton
            // 
            this.searchResponseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchResponseButton.Location = new System.Drawing.Point(571, 416);
            this.searchResponseButton.Name = "searchResponseButton";
            this.searchResponseButton.Size = new System.Drawing.Size(90, 33);
            this.searchResponseButton.TabIndex = 22;
            this.searchResponseButton.Text = "Search";
            this.searchResponseButton.UseVisualStyleBackColor = true;
            this.searchResponseButton.Click += new System.EventHandler(this.searchResponseButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(924, 424);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Matches: ";
            // 
            // matchesCountLabel
            // 
            this.matchesCountLabel.AutoSize = true;
            this.matchesCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matchesCountLabel.Location = new System.Drawing.Point(995, 424);
            this.matchesCountLabel.Name = "matchesCountLabel";
            this.matchesCountLabel.Size = new System.Drawing.Size(15, 16);
            this.matchesCountLabel.TabIndex = 24;
            this.matchesCountLabel.Text = "0";
            // 
            // fileUploadButton
            // 
            this.fileUploadButton.Enabled = false;
            this.fileUploadButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileUploadButton.Location = new System.Drawing.Point(91, 378);
            this.fileUploadButton.Name = "fileUploadButton";
            this.fileUploadButton.Size = new System.Drawing.Size(75, 23);
            this.fileUploadButton.TabIndex = 26;
            this.fileUploadButton.Text = "Select";
            this.fileUploadButton.UseVisualStyleBackColor = true;
            this.fileUploadButton.Click += new System.EventHandler(this.fileUploadButton_Click);
            // 
            // fileUploadName
            // 
            this.fileUploadName.AutoSize = true;
            this.fileUploadName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileUploadName.Location = new System.Drawing.Point(172, 381);
            this.fileUploadName.Name = "fileUploadName";
            this.fileUploadName.Size = new System.Drawing.Size(128, 16);
            this.fileUploadName.TabIndex = 27;
            this.fileUploadName.Text = "Select file to upload.";
            // 
            // customHeaderChkBox1
            // 
            this.customHeaderChkBox1.AutoSize = true;
            this.customHeaderChkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderChkBox1.Location = new System.Drawing.Point(24, 191);
            this.customHeaderChkBox1.Name = "customHeaderChkBox1";
            this.customHeaderChkBox1.Size = new System.Drawing.Size(131, 20);
            this.customHeaderChkBox1.TabIndex = 28;
            this.customHeaderChkBox1.Text = "Custom Header 1";
            this.customHeaderChkBox1.UseVisualStyleBackColor = true;
            this.customHeaderChkBox1.CheckedChanged += new System.EventHandler(this.customHeaderChkBox1_CheckedChanged);
            // 
            // customHeaderKeyTxtBox1
            // 
            this.customHeaderKeyTxtBox1.Enabled = false;
            this.customHeaderKeyTxtBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderKeyTxtBox1.Location = new System.Drawing.Point(163, 189);
            this.customHeaderKeyTxtBox1.Name = "customHeaderKeyTxtBox1";
            this.customHeaderKeyTxtBox1.Size = new System.Drawing.Size(137, 22);
            this.customHeaderKeyTxtBox1.TabIndex = 29;
            // 
            // customHeaderValueTxtBox1
            // 
            this.customHeaderValueTxtBox1.Enabled = false;
            this.customHeaderValueTxtBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderValueTxtBox1.Location = new System.Drawing.Point(306, 189);
            this.customHeaderValueTxtBox1.Name = "customHeaderValueTxtBox1";
            this.customHeaderValueTxtBox1.Size = new System.Drawing.Size(255, 22);
            this.customHeaderValueTxtBox1.TabIndex = 30;
            // 
            // customHeaderChkBox2
            // 
            this.customHeaderChkBox2.AutoSize = true;
            this.customHeaderChkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderChkBox2.Location = new System.Drawing.Point(24, 220);
            this.customHeaderChkBox2.Name = "customHeaderChkBox2";
            this.customHeaderChkBox2.Size = new System.Drawing.Size(131, 20);
            this.customHeaderChkBox2.TabIndex = 31;
            this.customHeaderChkBox2.Text = "Custom Header 2";
            this.customHeaderChkBox2.UseVisualStyleBackColor = true;
            this.customHeaderChkBox2.CheckedChanged += new System.EventHandler(this.customHeaderChkBox2_CheckedChanged);
            // 
            // customHeaderKeyTxtBox2
            // 
            this.customHeaderKeyTxtBox2.Enabled = false;
            this.customHeaderKeyTxtBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderKeyTxtBox2.Location = new System.Drawing.Point(163, 218);
            this.customHeaderKeyTxtBox2.Name = "customHeaderKeyTxtBox2";
            this.customHeaderKeyTxtBox2.Size = new System.Drawing.Size(137, 22);
            this.customHeaderKeyTxtBox2.TabIndex = 32;
            // 
            // customHeaderValueTxtBox2
            // 
            this.customHeaderValueTxtBox2.Enabled = false;
            this.customHeaderValueTxtBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderValueTxtBox2.Location = new System.Drawing.Point(306, 218);
            this.customHeaderValueTxtBox2.Name = "customHeaderValueTxtBox2";
            this.customHeaderValueTxtBox2.Size = new System.Drawing.Size(255, 22);
            this.customHeaderValueTxtBox2.TabIndex = 33;
            // 
            // keyLabelDisplay
            // 
            this.keyLabelDisplay.AutoSize = true;
            this.keyLabelDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyLabelDisplay.Location = new System.Drawing.Point(220, 170);
            this.keyLabelDisplay.Name = "keyLabelDisplay";
            this.keyLabelDisplay.Size = new System.Drawing.Size(31, 16);
            this.keyLabelDisplay.TabIndex = 34;
            this.keyLabelDisplay.Text = "Key";
            // 
            // valueLabelDisplay
            // 
            this.valueLabelDisplay.AutoSize = true;
            this.valueLabelDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valueLabelDisplay.Location = new System.Drawing.Point(409, 170);
            this.valueLabelDisplay.Name = "valueLabelDisplay";
            this.valueLabelDisplay.Size = new System.Drawing.Size(43, 16);
            this.valueLabelDisplay.TabIndex = 35;
            this.valueLabelDisplay.Text = "Value";
            // 
            // customHeaderChkBox3
            // 
            this.customHeaderChkBox3.AutoSize = true;
            this.customHeaderChkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderChkBox3.Location = new System.Drawing.Point(24, 248);
            this.customHeaderChkBox3.Name = "customHeaderChkBox3";
            this.customHeaderChkBox3.Size = new System.Drawing.Size(131, 20);
            this.customHeaderChkBox3.TabIndex = 36;
            this.customHeaderChkBox3.Text = "Custom Header 3";
            this.customHeaderChkBox3.UseVisualStyleBackColor = true;
            this.customHeaderChkBox3.CheckedChanged += new System.EventHandler(this.customHeaderChkBox3_CheckedChanged);
            // 
            // customHeaderKeyTxtBox3
            // 
            this.customHeaderKeyTxtBox3.Enabled = false;
            this.customHeaderKeyTxtBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderKeyTxtBox3.Location = new System.Drawing.Point(163, 246);
            this.customHeaderKeyTxtBox3.Name = "customHeaderKeyTxtBox3";
            this.customHeaderKeyTxtBox3.Size = new System.Drawing.Size(137, 22);
            this.customHeaderKeyTxtBox3.TabIndex = 37;
            // 
            // customHeaderValueTxtBox3
            // 
            this.customHeaderValueTxtBox3.Enabled = false;
            this.customHeaderValueTxtBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customHeaderValueTxtBox3.Location = new System.Drawing.Point(306, 246);
            this.customHeaderValueTxtBox3.Name = "customHeaderValueTxtBox3";
            this.customHeaderValueTxtBox3.Size = new System.Drawing.Size(255, 22);
            this.customHeaderValueTxtBox3.TabIndex = 38;
            // 
            // dataPayloadCheckBox
            // 
            this.dataPayloadCheckBox.AutoSize = true;
            this.dataPayloadCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataPayloadCheckBox.Location = new System.Drawing.Point(25, 312);
            this.dataPayloadCheckBox.Name = "dataPayloadCheckBox";
            this.dataPayloadCheckBox.Size = new System.Drawing.Size(56, 20);
            this.dataPayloadCheckBox.TabIndex = 39;
            this.dataPayloadCheckBox.Text = "Data";
            this.dataPayloadCheckBox.UseVisualStyleBackColor = true;
            this.dataPayloadCheckBox.CheckedChanged += new System.EventHandler(this.dataPayloadCheckBox_CheckedChanged);
            // 
            // fileUploadCheckBox
            // 
            this.fileUploadCheckBox.AutoSize = true;
            this.fileUploadCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileUploadCheckBox.Location = new System.Drawing.Point(25, 380);
            this.fileUploadCheckBox.Name = "fileUploadCheckBox";
            this.fileUploadCheckBox.Size = new System.Drawing.Size(49, 20);
            this.fileUploadCheckBox.TabIndex = 40;
            this.fileUploadCheckBox.Text = "File";
            this.fileUploadCheckBox.UseVisualStyleBackColor = true;
            this.fileUploadCheckBox.CheckedChanged += new System.EventHandler(this.fileUploadCheckBox_CheckedChanged);
            // 
            // cookieHeaderCheckBox
            // 
            this.cookieHeaderCheckBox.AutoSize = true;
            this.cookieHeaderCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cookieHeaderCheckBox.Location = new System.Drawing.Point(24, 146);
            this.cookieHeaderCheckBox.Name = "cookieHeaderCheckBox";
            this.cookieHeaderCheckBox.Size = new System.Drawing.Size(70, 20);
            this.cookieHeaderCheckBox.TabIndex = 41;
            this.cookieHeaderCheckBox.Text = "Cookie";
            this.cookieHeaderCheckBox.UseVisualStyleBackColor = true;
            this.cookieHeaderCheckBox.CheckedChanged += new System.EventHandler(this.cookieHeaderCheckBox_CheckedChanged);
            // 
            // cookieHeaderTextBox
            // 
            this.cookieHeaderTextBox.Enabled = false;
            this.cookieHeaderTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cookieHeaderTextBox.Location = new System.Drawing.Point(96, 144);
            this.cookieHeaderTextBox.Name = "cookieHeaderTextBox";
            this.cookieHeaderTextBox.Size = new System.Drawing.Size(463, 22);
            this.cookieHeaderTextBox.TabIndex = 42;
            // 
            // refererHeaderCheckBox
            // 
            this.refererHeaderCheckBox.AutoSize = true;
            this.refererHeaderCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refererHeaderCheckBox.Location = new System.Drawing.Point(24, 115);
            this.refererHeaderCheckBox.Name = "refererHeaderCheckBox";
            this.refererHeaderCheckBox.Size = new System.Drawing.Size(72, 20);
            this.refererHeaderCheckBox.TabIndex = 43;
            this.refererHeaderCheckBox.Text = "Referer";
            this.refererHeaderCheckBox.UseVisualStyleBackColor = true;
            this.refererHeaderCheckBox.CheckedChanged += new System.EventHandler(this.refererHeaderCheckBox_CheckedChanged);
            // 
            // refererHeaderTextBox
            // 
            this.refererHeaderTextBox.Enabled = false;
            this.refererHeaderTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refererHeaderTextBox.Location = new System.Drawing.Point(96, 113);
            this.refererHeaderTextBox.Name = "refererHeaderTextBox";
            this.refererHeaderTextBox.Size = new System.Drawing.Size(463, 22);
            this.refererHeaderTextBox.TabIndex = 44;
            // 
            // redirectsCheckBox
            // 
            this.redirectsCheckBox.AutoSize = true;
            this.redirectsCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.redirectsCheckBox.Location = new System.Drawing.Point(480, 17);
            this.redirectsCheckBox.Name = "redirectsCheckBox";
            this.redirectsCheckBox.Size = new System.Drawing.Size(85, 20);
            this.redirectsCheckBox.TabIndex = 45;
            this.redirectsCheckBox.Text = "Redirects";
            this.redirectsCheckBox.UseVisualStyleBackColor = true;
            // 
            // appForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 461);
            this.Controls.Add(this.redirectsCheckBox);
            this.Controls.Add(this.refererHeaderTextBox);
            this.Controls.Add(this.refererHeaderCheckBox);
            this.Controls.Add(this.cookieHeaderTextBox);
            this.Controls.Add(this.cookieHeaderCheckBox);
            this.Controls.Add(this.fileUploadCheckBox);
            this.Controls.Add(this.dataPayloadCheckBox);
            this.Controls.Add(this.customHeaderValueTxtBox3);
            this.Controls.Add(this.customHeaderKeyTxtBox3);
            this.Controls.Add(this.customHeaderChkBox3);
            this.Controls.Add(this.valueLabelDisplay);
            this.Controls.Add(this.keyLabelDisplay);
            this.Controls.Add(this.customHeaderValueTxtBox2);
            this.Controls.Add(this.customHeaderKeyTxtBox2);
            this.Controls.Add(this.customHeaderChkBox2);
            this.Controls.Add(this.customHeaderValueTxtBox1);
            this.Controls.Add(this.customHeaderKeyTxtBox1);
            this.Controls.Add(this.customHeaderChkBox1);
            this.Controls.Add(this.fileUploadName);
            this.Controls.Add(this.fileUploadButton);
            this.Controls.Add(this.matchesCountLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.searchResponseButton);
            this.Controls.Add(this.searchResponseTextBox);
            this.Controls.Add(this.responseTextBox);
            this.Controls.Add(this.hostHeaderTextBox);
            this.Controls.Add(this.hostHeaderCheckBox);
            this.Controls.Add(this.contentTypeComboBox);
            this.Controls.Add(this.resetValuesButton);
            this.Controls.Add(this.httpProtocolComboBox);
            this.Controls.Add(this.userAgentTextBox);
            this.Controls.Add(this.userAgentDisplayLabel);
            this.Controls.Add(this.dataPayloadTextBox);
            this.Controls.Add(this.postDataCheckbox);
            this.Controls.Add(this.httpMethodsComboBox);
            this.Controls.Add(this.sendUrlButton);
            this.Controls.Add(this.urlTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "appForm";
            this.Text = "csweb";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox urlTextBox;
        private System.Windows.Forms.Button sendUrlButton;
        private System.Windows.Forms.ComboBox httpMethodsComboBox;
        private System.Windows.Forms.CheckBox postDataCheckbox;
        private System.Windows.Forms.TextBox dataPayloadTextBox;
        private System.Windows.Forms.Label userAgentDisplayLabel;
        private System.Windows.Forms.TextBox userAgentTextBox;
        private System.Windows.Forms.ComboBox httpProtocolComboBox;
        private System.Windows.Forms.Button resetValuesButton;
        private System.Windows.Forms.ComboBox contentTypeComboBox;
        private System.Windows.Forms.CheckBox hostHeaderCheckBox;
        private System.Windows.Forms.RichTextBox responseTextBox;
        private System.Windows.Forms.TextBox hostHeaderTextBox;
        private System.Windows.Forms.TextBox searchResponseTextBox;
        private System.Windows.Forms.Button searchResponseButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label matchesCountLabel;
        private System.Windows.Forms.Button fileUploadButton;
        private System.Windows.Forms.Label fileUploadName;
        private System.Windows.Forms.CheckBox customHeaderChkBox1;
        private System.Windows.Forms.TextBox customHeaderKeyTxtBox1;
        private System.Windows.Forms.TextBox customHeaderValueTxtBox1;
        private System.Windows.Forms.CheckBox customHeaderChkBox2;
        private System.Windows.Forms.TextBox customHeaderKeyTxtBox2;
        private System.Windows.Forms.TextBox customHeaderValueTxtBox2;
        private System.Windows.Forms.Label keyLabelDisplay;
        private System.Windows.Forms.Label valueLabelDisplay;
        private System.Windows.Forms.CheckBox customHeaderChkBox3;
        private System.Windows.Forms.TextBox customHeaderKeyTxtBox3;
        private System.Windows.Forms.TextBox customHeaderValueTxtBox3;
        private System.Windows.Forms.CheckBox dataPayloadCheckBox;
        private System.Windows.Forms.CheckBox fileUploadCheckBox;
        private System.Windows.Forms.CheckBox cookieHeaderCheckBox;
        private System.Windows.Forms.TextBox cookieHeaderTextBox;
        private System.Windows.Forms.CheckBox refererHeaderCheckBox;
        private System.Windows.Forms.TextBox refererHeaderTextBox;
        private System.Windows.Forms.CheckBox redirectsCheckBox;
    }
}

