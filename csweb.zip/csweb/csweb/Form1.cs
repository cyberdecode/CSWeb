﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;

namespace csweb
{
    public partial class appForm : Form
    {
        public appForm()
        {
            InitializeComponent();
        }

        private void sendUrlButton_Click(object sender, EventArgs e)
        {

            // clear the previous response
            responseTextBox.Text = "";

            try
            {
                // create the new web request with value from URL textbox
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestUriString: httpProtocolComboBox.Text + "://" + urlTextBox.Text);

                // define the HTTP method with selection from drop-down
                request.Method = httpMethodsComboBox.Text;

                // check auto redirects
                if (redirectsCheckBox.Checked)
                {
                    request.AllowAutoRedirect = true;
                }
                else
                {
                    request.AllowAutoRedirect = false;
                }

                // check protocol version
                if (hostHeaderCheckBox.Checked)
                {
                    request.ProtocolVersion = HttpVersion.Version11;
                    request.Host = hostHeaderTextBox.Text;
                }
                else
                {
                    request.ProtocolVersion = HttpVersion.Version10;
                }

                // check if data payload attached
                if (postDataCheckbox.Checked)
                {
                    var data = Encoding.ASCII.GetBytes(dataPayloadTextBox.Text);
                    request.ContentType = contentTypeComboBox.Text;
                    request.ContentLength = data.Length;

                    // append data payload to request stream
                    using (var stream = request.GetRequestStream())
                    {
                        stream.Write(data, 0, data.Length);
                    }
                }

                // check if cookie value selected
                if (cookieHeaderCheckBox.Checked)
                {
                    request.Headers["Cookie"] = cookieHeaderTextBox.Text;
                }

                // check the referer value
                if (refererHeaderCheckBox.Checked)
                {
                    request.Referer = refererHeaderTextBox.Text;
                }

                // check custom header 1
                if (customHeaderChkBox1.Checked)
                {
                    request.Headers[customHeaderKeyTxtBox1.Text] = customHeaderValueTxtBox1.Text;
                }

                // check custom header 2
                if (customHeaderChkBox2.Checked)
                {
                    request.Headers[customHeaderKeyTxtBox2.Text] = customHeaderValueTxtBox2.Text;
                }

                // check custom header 3
                if (customHeaderChkBox3.Checked)
                {
                    request.Headers[customHeaderKeyTxtBox3.Text] = customHeaderValueTxtBox3.Text;
                }

                // set the User Agent with value from User-Agent textbox
                ((HttpWebRequest)request).UserAgent = userAgentTextBox.Text;

                // send the web request
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                var statusNumber = 0;
                statusNumber = (int)response.StatusCode;
                responseTextBox.AppendText(text: "HTTP " + statusNumber.ToString() + " " + response.StatusDescription + "\n");

                // display all the HEADERS
                for (int i = 0; i < response.Headers.Count; ++i)

                    responseTextBox.AppendText(text: response.Headers.Keys[i] + " : " + response.Headers[i] + "\n");

                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();

                // display server response text
                responseTextBox.AppendText(text: "\n" + responseFromServer);

                // close streams
                reader.Close();
                dataStream.Close();
                response.Close();

            }
            catch (Exception ex)
            {
                responseTextBox.AppendText(text: ex + "\n\n");
                return;

            }
        }


        private void postDataCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (postDataCheckbox.Checked)
            {
                contentTypeComboBox.Enabled = true;
            }

            else
            {
                contentTypeComboBox.Enabled = false;
            }
        }

        private void resetValuesButton_Click(object sender, EventArgs e)
        {
            // reset all values
            
            responseTextBox.Text = "";
            urlTextBox.Text = "";
            dataPayloadTextBox.Text = "";
            httpProtocolComboBox.Text = "HTTP";
            httpMethodsComboBox.Text = "GET";
            userAgentTextBox.Text = "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6";
            dataPayloadTextBox.Text = "";
            contentTypeComboBox.Text = "application/x-www-form-urlencoded";
            postDataCheckbox.Checked = false;
            hostHeaderCheckBox.Checked = false;
            hostHeaderTextBox.Text = "";

        }

        private void hostHeaderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (hostHeaderCheckBox.Checked)
            {
                hostHeaderTextBox.Enabled = true;
            }
            else
            {
                hostHeaderTextBox.Enabled = false;
            }
        }

        private void searchResponseButton_Click(object sender, EventArgs e)
        {
            
            int newLineOffset = Environment.NewLine.Length - 1; // "\r\n" - "\n";
            int lineStart = 0;

            int matches = 0;
            matchesCountLabel.Text = matches.ToString();

            foreach (string line in responseTextBox.Lines)
            {
                foreach (Match match in Regex.Matches(line, String.Format(@"\b{0}\b", searchResponseTextBox.Text)))
                {
                    responseTextBox.Select(lineStart + match.Index, match.Length);
                    responseTextBox.SelectionBackColor = Color.Yellow;

                    matches += 1;
                    matchesCountLabel.Text = matches.ToString();
                }

                lineStart += line.Length + newLineOffset;

            }
        }

        private void fileUploadButton_Click(object sender, EventArgs e)
        {
            // Displays an OpenFileDialog so the user can select a Cursor.  
            OpenFileDialog fileUploadDialogWindow = new OpenFileDialog();
            fileUploadDialogWindow.Title = "Select a File";

            // Show the Dialog.  
            // If the user clicked OK in the dialog and  
            // a .CUR file was selected, open it.  
            if (fileUploadDialogWindow.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                fileUploadName.Text = fileUploadDialogWindow.FileName;

            }
        }

        private void fileUploadCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (fileUploadCheckBox.Checked)
            {
                fileUploadButton.Enabled = true;
            }
            else
            {
                fileUploadButton.Enabled = false;
            }
        }

        private void dataPayloadCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (dataPayloadCheckBox.Checked)
            {
                dataPayloadTextBox.Enabled = true;
            }
            else
            {
                dataPayloadTextBox.Enabled = false;
            }
        }

        private void customHeaderChkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (customHeaderChkBox1.Checked)
            {
                customHeaderKeyTxtBox1.Enabled = true;
                customHeaderValueTxtBox1.Enabled = true;
            }
            else
            {
                customHeaderKeyTxtBox1.Enabled = false;
                customHeaderValueTxtBox1.Enabled = false;
            }
        }

        private void customHeaderChkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (customHeaderChkBox2.Checked)
            {
                customHeaderKeyTxtBox2.Enabled = true;
                customHeaderValueTxtBox2.Enabled = true;
            }
            else
            {
                customHeaderKeyTxtBox2.Enabled = false;
                customHeaderValueTxtBox2.Enabled = false;
            }
        }


        private void customHeaderChkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (customHeaderChkBox3.Checked)
            {
                customHeaderKeyTxtBox3.Enabled = true;
                customHeaderValueTxtBox3.Enabled = true;
            }
            else
            {
                customHeaderKeyTxtBox3.Enabled = false;
                customHeaderValueTxtBox3.Enabled = false;
            }
        }

        private void cookieHeaderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (cookieHeaderCheckBox.Checked)
            {
                cookieHeaderTextBox.Enabled = true;
            }
            else
            {
                cookieHeaderTextBox.Enabled = false;
            }

        }

        private void refererHeaderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (refererHeaderCheckBox.Checked)
            {
                refererHeaderTextBox.Enabled = true;
            }
            else
            {
                refererHeaderTextBox.Enabled = false;
            }

        }
    }
}
