﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;

namespace csweb
{
    public partial class appForm : Form
    {
        public appForm()
        {
            InitializeComponent();
        }

        private void sendUrlButton_Click(object sender, EventArgs e)
        {

            // clear the previous response
            responseTextBox.Text = "";

            // create the new web request with value from URL textbox
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestUriString: httpProtocolComboBox.Text + "://" + urlTextBox.Text);

            // define the HTTP method with selection from drop-down
            request.Method = httpMethodsComboBox.Text;

            // prohibit auto redirects
            request.AllowAutoRedirect = false;

            // check if data payload attached
            if (postDataCheckbox.Checked)
            {
                var data = Encoding.ASCII.GetBytes(dataPayloadTextBox.Text);
                request.ContentType = contentTypeComboBox.Text;
                request.ContentLength = data.Length;

                // append data payload to request stream
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
            }

            // check if cookie value selected
            if (cookieHeaderCheckBox.Checked)
            {
                request.Headers["Cookie"] = cookieHeaderTextBox.Text;
            }
            
            // set the User Agent with value from User-Agent textbox
            ((HttpWebRequest)request).UserAgent = userAgentTextBox.Text;

            try
            {
                // send the web request
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                var statusNumber = 0;
                statusNumber = (int)response.StatusCode;
                responseTextBox.AppendText(text: "HTTP " + statusNumber.ToString() + " " + response.StatusDescription + "\n");

                // display all the HEADERS
                for (int i = 0; i < response.Headers.Count; ++i)

                    responseTextBox.AppendText(text: response.Headers.Keys[i] + " : " + response.Headers[i] + "\n");

                Stream dataStream = response.GetResponseStream();              
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();

                // display server response text
                responseTextBox.AppendText(text: "\n" + responseFromServer);
                
                // close streams
                reader.Close();
                dataStream.Close();
                response.Close();
            }

            catch (WebException ex)
            {
                responseTextBox.AppendText(ex + Environment.NewLine + Environment.NewLine);
            }
            
            
        }

       

        private void postDataCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (postDataCheckbox.Checked)
            {
                contentTypeComboBox.Enabled = true;
                dataPayloadTextBox.Enabled = true;
            }

            else
            {
                contentTypeComboBox.Enabled = false;
                dataPayloadTextBox.Enabled = false;
            }
        }

        private void resetValuesButton_Click(object sender, EventArgs e)
        {
            // reset all values
            
            responseTextBox.Text = "";
            urlTextBox.Text = "";
            dataPayloadTextBox.Text = "";
            httpProtocolComboBox.Text = "HTTP";
            httpMethodsComboBox.Text = "GET";
            userAgentTextBox.Text = "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6";
            dataPayloadTextBox.Text = "";
            contentTypeComboBox.Text = "application/x-www-form-urlencoded";
            postDataCheckbox.Checked = false;
            cookieHeaderCheckBox.Checked = false;
            cookieHeaderTextBox.Text = "";

        }

        private void cookieHeaderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (cookieHeaderCheckBox.Checked)
            {
                cookieHeaderTextBox.Enabled = true;
            }
            else
            {
                cookieHeaderTextBox.Enabled = false;
            }
        }

        private void searchResponseButton_Click(object sender, EventArgs e)
        {
            
            int newLineOffset = Environment.NewLine.Length - 1; // "\r\n" - "\n";
            int lineStart = 0;

            int matches = 0;
            matchesCountLabel.Text = matches.ToString();

            foreach (string line in responseTextBox.Lines)
            {
                foreach (Match match in Regex.Matches(line, String.Format(@"\b{0}\b", searchResponseTextBox.Text)))
                {
                    responseTextBox.Select(lineStart + match.Index, match.Length);
                    responseTextBox.SelectionBackColor = Color.Yellow;

                    matches += 1;
                    matchesCountLabel.Text = matches.ToString();
                }

                lineStart += line.Length + newLineOffset;

            }
        }
    }
}
